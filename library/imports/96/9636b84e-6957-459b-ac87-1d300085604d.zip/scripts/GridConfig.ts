export const GridConfig = {
    width: 100,
    height: 112,
    startXPosition: -410,
    startYPosition: 440,
    behindScreen: 600
}