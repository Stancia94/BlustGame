export const EventBus = new cc.EventTarget();
